export const environment = {
    production: true,
    firebaseConfig: {
        apiKey: 'AIzaSyDPtnERtJfy7iNCmoT661-rRgkrRdfyDPY',
        authDomain: 'humanis-2020.firebaseapp.com',
        databaseURL: 'https://humanis-2020.firebaseio.com',
        projectId: 'humanis-2020',
        storageBucket: 'humanis-2020.appspot.com',
        messagingSenderId: '426951655222',
        appId: '1:426951655222:web:5373aa328f1a45ca6d3d97',
        measurementId: 'G-B9XTTKCW55'
    },
    // apiURL: 'http://localhost/atina/atina-api',
    apiURL: 'http://app.atina.co.id/api',
    // apiURL: 'http://atina.landa.id/api',
    // imageURL: 'http://localhost/atina/atina-api/assets/img/',
    imageURL: 'http://app.atina.co.id/api/assets/img/',
    // imageURL: 'http://atina.landa.id/api/assets/img/',

};